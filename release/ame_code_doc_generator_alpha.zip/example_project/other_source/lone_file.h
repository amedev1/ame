#ifndef LONE_FILE_H
#define LONE_FILE_H

/* foo var */
int foo = 3;

struct bar // bar struct
{
	int a;
	int b;
};

#endif