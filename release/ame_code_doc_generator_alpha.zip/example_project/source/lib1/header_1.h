#ifndef header1_h
#define header1_h

/* @module lib1 module
 * this is the documentation for the current module
 * it can only be set once per module */

// a C function
void my_function(char *my_param);

/* a different C function */
int my_other_function(void)
{
    return 0;
}

/* a C function pointer */
typedef void (*my_function_pointer)(int);

#endif