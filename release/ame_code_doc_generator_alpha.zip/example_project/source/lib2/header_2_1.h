#ifndef header2_1_h
#define header2_1_h

/* a C struct
 * with a multi-line comment */
typedef struct {
	int  a;
	char b;
} MyStruct;

// a C enum
typedef enum {
	VAL_0,
	VAL_1,
} MyEnum;

// a C enum with value comments
typedef enum {
	FOO_0, // foor
	BAR_1, /* bar */
} MyEnum2;

/* a C union */
typedef union {
	int   a;
	float b;
} MyUion;

#endif