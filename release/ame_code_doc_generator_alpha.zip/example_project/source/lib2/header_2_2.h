
#ifndef HEADER2_2_H
#define HEADER2_2_H

// a variable
int my_var;

/* another C variable */
int my_var_2;

int my_var_3; /* another C variable */

int my_var_4; /* another C variable */

/* @section ExampleSection
 * this comment adds a new section in the module 
 * Empty sections won't be displayed */

/* a C preprocessor constant */
#define MY_VAL 0 

#define MY_VAL_1 0 /* another preprocessor constant */

#define MY_VAL_2 0 // another preprocessor constant

/* a preprocessor macro
 * with multi-line comment
 */
#define MY_MACRO(param) do_something(param)\
do_something_else()

#endif