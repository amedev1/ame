ame - 2020
Code_doc_generator - alpha version

Tool to generate C code documentation in HTML

USAGE: code_doc_generator path
       file mode
USAGE: code_doc_generator -i
       interactive mode

***************************************************

Commands (either in interactive mode or file mode):

project          path name description signature
                 configure project
module           name description
                 add a doc module to project
section          module name description
                 add a doc section to project
element          module section type name content [description]
                 add a doc element to project
c_file           module path
                 parse c_file and add to module
cmake_file       module path
                 parse cmake_file and add to module
c_folder         module path
                 parse folder for c files and add to module
cmake_folder     module path
                 parse folder for cmake files and add to module
generate
                 generate project
exit
                 exit interactive mode

***************************************************

Notes:
- for each command, arguments are words separated by space or double quotes: ie: module "my module name" a_description
- in file mode, using "." as project path will use the folder of input file as root directory
- for commands module, section, and element, description and content argumenst must be on one line, but special strinsg \n \t \r will be transformed accordingly
- for command element, possibles values for type parameter:
  * CMAKE_MACRO
  * C_DEFINE
  * C_FUNCTION
  * C_FUNCTION_POINTER
  * C_STRUCT
  * C_UNION
  * C_ENUM
  * C_TYPEDEF
  * C_VARIABLE
  * C_CODE
  *	TEXT
- generated files will output in the same folder as the executable, in a folder named YYYYMMDDHHSS_project_name